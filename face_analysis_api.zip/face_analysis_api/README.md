# Face Analysis API

Ready-to-deploy FastAPI service that runs the facial measurement engine.

## Quick Deploy Options

### 1. Railway (easiest)
1. Go to https://railway.app and sign up
2. Click “New Project” → “Deploy from GitHub repo” (or upload this folder)
3. Railway will detect the Dockerfile and deploy
4. Copy the public URL it gives you (e.g. `https://your-app.up.railway.app`)

### 2. Render
1. Go to https://render.com
2. New → Web Service
3. Upload this folder or connect a repo
4. Use the Dockerfile
5. Set start command if needed: `uvicorn main:app --host 0.0.0.0 --port $PORT`

### 3. Local test
```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Then open http://localhost:8000/docs

## Endpoints

- `GET /health` → check if the model is loaded
- `POST /analyze` → upload photos, get measurements
- `GET /docs` → interactive Swagger UI

## Example call (from Base44 or any frontend)

```javascript
const formData = new FormData();
formData.append("front", frontPhotoFile);

const response = await fetch("https://YOUR-API-URL/analyze", {
  method: "POST",
  body: formData
});

const data = await response.json();
console.log(data.scores);
console.log(data.facial_thirds);
```
